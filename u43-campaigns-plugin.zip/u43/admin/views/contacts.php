<?php
/**
 * Contacts View
 *
 * @package U43
 */

if (!defined('ABSPATH')) {
    exit;
}

$contact_manager = new \U43\Campaigns\Contact_Manager();
$folder_id = isset($_GET['folder_id']) ? intval($_GET['folder_id']) : '';
$tag_id = isset($_GET['tag_id']) ? intval($_GET['tag_id']) : '';
$search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;

$contacts_data = $contact_manager->get_contacts([
    'folder_id' => $folder_id,
    'tag_id' => $tag_id,
    'search' => $search,
    'page' => $page,
    'per_page' => 50
]);

$contacts = $contacts_data['items'];
$total_pages = $contacts_data['pages'];

$folders = $contact_manager->get_folders();
$tags = $contact_manager->get_tags();
?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?php esc_html_e('Contacts', 'u43'); ?></h1>
    <a href="#" class="page-title-action" id="import-contacts-btn"><?php esc_html_e('Import Contacts', 'u43'); ?></a>
    <a href="#" class="page-title-action" id="add-contact-btn"><?php esc_html_e('Add Contact', 'u43'); ?></a>
    
    <hr class="wp-header-end">
    
    <div class="tablenav top">
        <div class="alignleft actions">
            <form method="get" action="">
                <input type="hidden" name="page" value="u43-contacts">
                <select name="folder_id">
                    <option value=""><?php esc_html_e('All Folders', 'u43'); ?></option>
                    <?php foreach ($folders as $folder): ?>
                        <option value="<?php echo esc_attr($folder->id); ?>" <?php selected($folder_id, $folder->id); ?>>
                            <?php echo esc_html($folder->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select name="tag_id">
                    <option value=""><?php esc_html_e('All Tags', 'u43'); ?></option>
                    <?php foreach ($tags as $tag): ?>
                        <option value="<?php echo esc_attr($tag->id); ?>" <?php selected($tag_id, $tag->id); ?>>
                            <?php echo esc_html($tag->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search contacts...', 'u43'); ?>">
                <button type="submit" class="button"><?php esc_html_e('Filter', 'u43'); ?></button>
            </form>
        </div>
    </div>
    
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th><?php esc_html_e('Name', 'u43'); ?></th>
                <th><?php esc_html_e('Phone', 'u43'); ?></th>
                <th><?php esc_html_e('Tags', 'u43'); ?></th>
                <th><?php esc_html_e('Folder', 'u43'); ?></th>
                <th><?php esc_html_e('Created', 'u43'); ?></th>
                <th><?php esc_html_e('Actions', 'u43'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($contacts)): ?>
                <tr>
                    <td colspan="6"><?php esc_html_e('No contacts found.', 'u43'); ?></td>
                </tr>
            <?php else: ?>
                <?php foreach ($contacts as $contact): ?>
                    <tr>
                        <td><strong><?php echo esc_html($contact->name); ?></strong></td>
                        <td><?php echo esc_html($contact->phone); ?></td>
                        <td>
                            <?php if (!empty($contact->tags)): ?>
                                <?php foreach ($contact->tags as $tag): ?>
                                    <span class="tag" style="background: <?php echo esc_attr($tag->color); ?>; color: white; padding: 2px 8px; border-radius: 3px; font-size: 11px;">
                                        <?php echo esc_html($tag->name); ?>
                                    </span>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <span class="description"><?php esc_html_e('No tags', 'u43'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $folder_name = '';
                            foreach ($folders as $folder) {
                                if ($folder->id == $contact->folder_id) {
                                    $folder_name = $folder->name;
                                    break;
                                }
                            }
                            echo esc_html($folder_name ?: '-');
                            ?>
                        </td>
                        <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($contact->created_at))); ?></td>
                        <td>
                            <a href="#" class="edit-contact" data-id="<?php echo esc_attr($contact->id); ?>"><?php esc_html_e('Edit', 'u43'); ?></a> |
                            <a href="#" class="delete-contact" data-id="<?php echo esc_attr($contact->id); ?>"><?php esc_html_e('Delete', 'u43'); ?></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <?php if ($total_pages > 1): ?>
        <div class="tablenav">
            <div class="tablenav-pages">
                <?php
                echo paginate_links([
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $total_pages,
                    'current' => $page
                ]);
                ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Import Contacts Modal -->
<div id="import-contacts-modal" style="display:none;">
    <div class="u43-modal-content">
        <h2><?php esc_html_e('Import Contacts from CSV', 'u43'); ?></h2>
        <form id="import-contacts-form" enctype="multipart/form-data">
            <p>
                <label><?php esc_html_e('CSV File', 'u43'); ?></label><br>
                <input type="file" name="csv_file" accept=".csv" required>
            </p>
            <p>
                <label><input type="checkbox" name="skip_first_row" checked> <?php esc_html_e('Skip first row (headers)', 'u43'); ?></label>
            </p>
            <p>
                <label><?php esc_html_e('Name Column', 'u43'); ?></label>
                <input type="number" name="name_column" value="0" min="0" class="small-text">
            </p>
            <p>
                <label><?php esc_html_e('Phone Column', 'u43'); ?></label>
                <input type="number" name="phone_column" value="1" min="0" class="small-text">
            </p>
            <p>
                <label><?php esc_html_e('Tags Column', 'u43'); ?></label>
                <input type="number" name="tags_column" value="2" min="0" class="small-text">
            </p>
            <p class="submit">
                <button type="submit" class="button button-primary"><?php esc_html_e('Import', 'u43'); ?></button>
                <button type="button" class="button cancel-modal"><?php esc_html_e('Cancel', 'u43'); ?></button>
            </p>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#import-contacts-btn').on('click', function(e) {
        e.preventDefault();
        $('#import-contacts-modal').show();
    });
    
    $('.cancel-modal').on('click', function() {
        $('#import-contacts-modal').hide();
    });
    
    $('#import-contacts-form').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        
        $.ajax({
            url: '<?php echo esc_url(rest_url('u43/v1/contacts/import')); ?>',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', '<?php echo wp_create_nonce('wp_rest'); ?>');
            },
            success: function(response) {
                alert('Imported: ' + response.imported + ', Skipped: ' + response.skipped);
                location.reload();
            },
            error: function(xhr) {
                alert('Error importing contacts: ' + (xhr.responseJSON?.message || 'Unknown error'));
            }
        });
    });
});
</script>

<style>
#import-contacts-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 100000;
}
.u43-modal-content {
    background: white;
    padding: 20px;
    margin: 50px auto;
    max-width: 600px;
    border-radius: 4px;
}
</style>

