<?php
/**
 * Segments View (Tags and Folders)
 *
 * @package U43
 */

if (!defined('ABSPATH')) {
    exit;
}

$contact_manager = new \U43\Campaigns\Contact_Manager();
$tags = $contact_manager->get_tags();
$folders = $contact_manager->get_folders();
?>

<div class="wrap">
    <h1><?php esc_html_e('Segments', 'u43'); ?></h1>
    
    <div class="nav-tab-wrapper">
        <a href="#tags-tab" class="nav-tab nav-tab-active"><?php esc_html_e('Tags', 'u43'); ?></a>
        <a href="#folders-tab" class="nav-tab"><?php esc_html_e('Folders', 'u43'); ?></a>
    </div>
    
    <!-- Tags Tab -->
    <div id="tags-tab" class="tab-content">
        <h2><?php esc_html_e('Tags', 'u43'); ?></h2>
        <button type="button" class="button" id="add-tag-btn"><?php esc_html_e('Add Tag', 'u43'); ?></button>
        
        <table class="wp-list-table widefat fixed striped" style="margin-top: 20px;">
            <thead>
                <tr>
                    <th><?php esc_html_e('Name', 'u43'); ?></th>
                    <th><?php esc_html_e('Color', 'u43'); ?></th>
                    <th><?php esc_html_e('Created', 'u43'); ?></th>
                    <th><?php esc_html_e('Actions', 'u43'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($tags)): ?>
                    <tr>
                        <td colspan="4"><?php esc_html_e('No tags found.', 'u43'); ?></td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($tags as $tag): ?>
                        <tr>
                            <td><strong><?php echo esc_html($tag->name); ?></strong></td>
                            <td><span style="display: inline-block; width: 20px; height: 20px; background: <?php echo esc_attr($tag->color); ?>; border-radius: 3px;"></span></td>
                            <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($tag->created_at))); ?></td>
                            <td>
                                <a href="#" class="delete-tag" data-id="<?php echo esc_attr($tag->id); ?>"><?php esc_html_e('Delete', 'u43'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Folders Tab -->
    <div id="folders-tab" class="tab-content" style="display:none;">
        <h2><?php esc_html_e('Folders', 'u43'); ?></h2>
        <button type="button" class="button" id="add-folder-btn"><?php esc_html_e('Add Folder', 'u43'); ?></button>
        
        <table class="wp-list-table widefat fixed striped" style="margin-top: 20px;">
            <thead>
                <tr>
                    <th><?php esc_html_e('Name', 'u43'); ?></th>
                    <th><?php esc_html_e('Description', 'u43'); ?></th>
                    <th><?php esc_html_e('Created', 'u43'); ?></th>
                    <th><?php esc_html_e('Actions', 'u43'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($folders)): ?>
                    <tr>
                        <td colspan="4"><?php esc_html_e('No folders found.', 'u43'); ?></td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($folders as $folder): ?>
                        <tr>
                            <td><strong><?php echo esc_html($folder->name); ?></strong></td>
                            <td><?php echo esc_html($folder->description ?: '-'); ?></td>
                            <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($folder->created_at))); ?></td>
                            <td>
                                <a href="#" class="edit-folder" data-id="<?php echo esc_attr($folder->id); ?>"><?php esc_html_e('Edit', 'u43'); ?></a> |
                                <a href="#" class="delete-folder" data-id="<?php echo esc_attr($folder->id); ?>"><?php esc_html_e('Delete', 'u43'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('.nav-tab').on('click', function(e) {
        e.preventDefault();
        var tab = $(this).attr('href');
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        $('.tab-content').hide();
        $(tab).show();
    });
    
    $('#add-tag-btn').on('click', function() {
        var tagName = prompt('<?php esc_html_e('Enter tag name:', 'u43'); ?>');
        if (tagName) {
            $.ajax({
                url: '<?php echo esc_url(rest_url('u43/v1/tags')); ?>',
                method: 'POST',
                data: JSON.stringify({ name: tagName }),
                contentType: 'application/json',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', '<?php echo wp_create_nonce('wp_rest'); ?>');
                },
                success: function() {
                    location.reload();
                }
            });
        }
    });
    
    $('#add-folder-btn').on('click', function() {
        var folderName = prompt('<?php esc_html_e('Enter folder name:', 'u43'); ?>');
        if (folderName) {
            $.ajax({
                url: '<?php echo esc_url(rest_url('u43/v1/folders')); ?>',
                method: 'POST',
                data: JSON.stringify({ name: folderName }),
                contentType: 'application/json',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', '<?php echo wp_create_nonce('wp_rest'); ?>');
                },
                success: function() {
                    location.reload();
                }
            });
        }
    });
});
</script>

