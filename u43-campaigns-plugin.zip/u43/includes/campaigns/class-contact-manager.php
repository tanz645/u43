<?php
/**
 * Contact Manager
 *
 * @package U43
 */

namespace U43\Campaigns;

class Contact_Manager {
    
    private $wpdb;
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }
    
    /**
     * Get all contacts
     *
     * @param array $args Query arguments
     * @return array
     */
    public function get_contacts($args = []) {
        $defaults = [
            'folder_id' => '',
            'tag_id' => '',
            'search' => '',
            'per_page' => 50,
            'page' => 1,
            'orderby' => 'created_at',
            'order' => 'DESC'
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $table = $this->wpdb->prefix . 'u43_campaign_contacts';
        $contact_tags_table = $this->wpdb->prefix . 'u43_campaign_contact_tags';
        
        $where = '1=1';
        $joins = '';
        
        if (!empty($args['folder_id'])) {
            $where .= $this->wpdb->prepare(' AND folder_id = %d', $args['folder_id']);
        }
        
        if (!empty($args['tag_id'])) {
            $joins .= " INNER JOIN $contact_tags_table ct ON c.id = ct.contact_id";
            $where .= $this->wpdb->prepare(' AND ct.tag_id = %d', $args['tag_id']);
        }
        
        if (!empty($args['search'])) {
            $search = '%' . $this->wpdb->esc_like($args['search']) . '%';
            $where .= $this->wpdb->prepare(' AND (name LIKE %s OR phone LIKE %s)', $search, $search);
        }
        
        $offset = ($args['page'] - 1) * $args['per_page'];
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']);
        
        $query = "SELECT c.* FROM $table c $joins WHERE $where ORDER BY c.$orderby LIMIT %d OFFSET %d";
        $contacts = $this->wpdb->get_results($this->wpdb->prepare($query, $args['per_page'], $offset));
        
        // Get tags for each contact
        foreach ($contacts as $contact) {
            $contact->tags = $this->get_contact_tags($contact->id);
        }
        
        $total = $this->wpdb->get_var("SELECT COUNT(DISTINCT c.id) FROM $table c $joins WHERE $where");
        
        return [
            'items' => $contacts,
            'total' => (int) $total,
            'pages' => ceil($total / $args['per_page'])
        ];
    }
    
    /**
     * Get contact by ID
     *
     * @param int $contact_id Contact ID
     * @return object|null
     */
    public function get_contact($contact_id) {
        $table = $this->wpdb->prefix . 'u43_campaign_contacts';
        $contact = $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM $table WHERE id = %d", $contact_id));
        
        if ($contact) {
            $contact->tags = $this->get_contact_tags($contact_id);
        }
        
        return $contact;
    }
    
    /**
     * Create contact
     *
     * @param array $data Contact data
     * @return int|false Contact ID or false on failure
     */
    public function create_contact($data) {
        $table = $this->wpdb->prefix . 'u43_campaign_contacts';
        
        $defaults = [
            'name' => '',
            'phone' => '',
            'folder_id' => null,
            'notes' => '',
            'created_by' => get_current_user_id()
        ];
        
        $data = wp_parse_args($data, $defaults);
        
        // Format phone number
        $data['phone'] = preg_replace('/[^\d]/', '', $data['phone']);
        
        $result = $this->wpdb->insert($table, $data);
        
        if ($result) {
            $contact_id = $this->wpdb->insert_id;
            
            // Add tags if provided
            if (!empty($data['tags']) && is_array($data['tags'])) {
                $this->set_contact_tags($contact_id, $data['tags']);
            }
            
            return $contact_id;
        }
        
        return false;
    }
    
    /**
     * Update contact
     *
     * @param int $contact_id Contact ID
     * @param array $data Contact data
     * @return bool
     */
    public function update_contact($contact_id, $data) {
        $table = $this->wpdb->prefix . 'u43_campaign_contacts';
        
        // Format phone number if provided
        if (isset($data['phone'])) {
            $data['phone'] = preg_replace('/[^\d]/', '', $data['phone']);
        }
        
        $result = $this->wpdb->update(
            $table,
            $data,
            ['id' => $contact_id]
        );
        
        // Update tags if provided
        if (isset($data['tags']) && is_array($data['tags'])) {
            $this->set_contact_tags($contact_id, $data['tags']);
        }
        
        return $result !== false;
    }
    
    /**
     * Delete contact
     *
     * @param int $contact_id Contact ID
     * @return bool
     */
    public function delete_contact($contact_id) {
        $table = $this->wpdb->prefix . 'u43_campaign_contacts';
        return $this->wpdb->delete($table, ['id' => $contact_id]) !== false;
    }
    
    /**
     * Import contacts from CSV
     *
     * @param string $file_path CSV file path
     * @param array $options Import options
     * @return array Results
     */
    public function import_contacts_from_csv($file_path, $options = []) {
        $defaults = [
            'skip_first_row' => true,
            'name_column' => 0,
            'phone_column' => 1,
            'tags_column' => 2,
            'folder_id' => null
        ];
        
        $options = wp_parse_args($options, $defaults);
        
        $results = [
            'imported' => 0,
            'skipped' => 0,
            'errors' => []
        ];
        
        if (!file_exists($file_path)) {
            $results['errors'][] = 'File not found';
            return $results;
        }
        
        $handle = fopen($file_path, 'r');
        if (!$handle) {
            $results['errors'][] = 'Could not open file';
            return $results;
        }
        
        $row_number = 0;
        
        while (($row = fgetcsv($handle)) !== false) {
            $row_number++;
            
            // Skip first row if it's headers
            if ($options['skip_first_row'] && $row_number === 1) {
                continue;
            }
            
            // Validate required columns
            if (!isset($row[$options['name_column']]) || !isset($row[$options['phone_column']])) {
                $results['skipped']++;
                $results['errors'][] = "Row $row_number: Missing required columns";
                continue;
            }
            
            $name = trim($row[$options['name_column']]);
            $phone = trim($row[$options['phone_column']]);
            $tags = isset($row[$options['tags_column']]) ? trim($row[$options['tags_column']]) : '';
            
            if (empty($name) || empty($phone)) {
                $results['skipped']++;
                continue;
            }
            
            // Parse tags (comma-separated)
            $tag_names = [];
            if (!empty($tags)) {
                $tag_names = array_map('trim', explode(',', $tags));
            }
            
            // Create or get tag IDs
            $tag_ids = [];
            foreach ($tag_names as $tag_name) {
                if (!empty($tag_name)) {
                    $tag_id = $this->get_or_create_tag($tag_name);
                    if ($tag_id) {
                        $tag_ids[] = $tag_id;
                    }
                }
            }
            
            // Check if contact already exists
            $existing = $this->get_contact_by_phone($phone);
            
            if ($existing) {
                // Update existing contact
                $this->update_contact($existing->id, [
                    'name' => $name,
                    'folder_id' => $options['folder_id'],
                    'tags' => $tag_ids
                ]);
            } else {
                // Create new contact
                $this->create_contact([
                    'name' => $name,
                    'phone' => $phone,
                    'folder_id' => $options['folder_id'],
                    'tags' => $tag_ids
                ]);
            }
            
            $results['imported']++;
        }
        
        fclose($handle);
        
        return $results;
    }
    
    /**
     * Get contact by phone number
     *
     * @param string $phone Phone number
     * @return object|null
     */
    public function get_contact_by_phone($phone) {
        $table = $this->wpdb->prefix . 'u43_campaign_contacts';
        $phone = preg_replace('/[^\d]/', '', $phone);
        return $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM $table WHERE phone = %s", $phone));
    }
    
    /**
     * Get contact tags
     *
     * @param int $contact_id Contact ID
     * @return array
     */
    public function get_contact_tags($contact_id) {
        $tags_table = $this->wpdb->prefix . 'u43_campaign_tags';
        $contact_tags_table = $this->wpdb->prefix . 'u43_campaign_contact_tags';
        
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT t.* FROM $tags_table t
            INNER JOIN $contact_tags_table ct ON t.id = ct.tag_id
            WHERE ct.contact_id = %d",
            $contact_id
        ));
    }
    
    /**
     * Set contact tags
     *
     * @param int $contact_id Contact ID
     * @param array $tag_ids Tag IDs
     * @return bool
     */
    public function set_contact_tags($contact_id, $tag_ids) {
        $table = $this->wpdb->prefix . 'u43_campaign_contact_tags';
        
        // Delete existing tags
        $this->wpdb->delete($table, ['contact_id' => $contact_id]);
        
        // Insert new tags
        foreach ($tag_ids as $tag_id) {
            $this->wpdb->insert($table, [
                'contact_id' => $contact_id,
                'tag_id' => $tag_id
            ]);
        }
        
        return true;
    }
    
    /**
     * Get all tags
     *
     * @return array
     */
    public function get_tags() {
        $table = $this->wpdb->prefix . 'u43_campaign_tags';
        return $this->wpdb->get_results("SELECT * FROM $table ORDER BY name");
    }
    
    /**
     * Get or create tag
     *
     * @param string $tag_name Tag name
     * @return int|false Tag ID or false
     */
    public function get_or_create_tag($tag_name) {
        $table = $this->wpdb->prefix . 'u43_campaign_tags';
        
        $tag = $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM $table WHERE name = %s", $tag_name));
        
        if ($tag) {
            return $tag->id;
        }
        
        // Create new tag
        $result = $this->wpdb->insert($table, ['name' => $tag_name]);
        
        if ($result) {
            return $this->wpdb->insert_id;
        }
        
        return false;
    }
    
    /**
     * Get all folders
     *
     * @return array
     */
    public function get_folders() {
        $table = $this->wpdb->prefix . 'u43_campaign_folders';
        return $this->wpdb->get_results("SELECT * FROM $table ORDER BY name");
    }
    
    /**
     * Create folder
     *
     * @param array $data Folder data
     * @return int|false Folder ID or false
     */
    public function create_folder($data) {
        $table = $this->wpdb->prefix . 'u43_campaign_folders';
        
        $defaults = [
            'name' => '',
            'description' => '',
            'created_by' => get_current_user_id()
        ];
        
        $data = wp_parse_args($data, $defaults);
        
        $result = $this->wpdb->insert($table, $data);
        
        if ($result) {
            return $this->wpdb->insert_id;
        }
        
        return false;
    }
    
    /**
     * Update folder
     *
     * @param int $folder_id Folder ID
     * @param array $data Folder data
     * @return bool
     */
    public function update_folder($folder_id, $data) {
        $table = $this->wpdb->prefix . 'u43_campaign_folders';
        return $this->wpdb->update($table, $data, ['id' => $folder_id]) !== false;
    }
    
    /**
     * Delete folder
     *
     * @param int $folder_id Folder ID
     * @return bool
     */
    public function delete_folder($folder_id) {
        $table = $this->wpdb->prefix . 'u43_campaign_folders';
        return $this->wpdb->delete($table, ['id' => $folder_id]) !== false;
    }
}

