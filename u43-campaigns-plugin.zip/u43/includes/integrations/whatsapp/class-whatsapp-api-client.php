<?php
/**
 * WhatsApp API Client
 *
 * @package U43
 */

namespace U43\Integrations\WhatsApp;

class WhatsApp_API_Client {
    
    private $api_token;
    private $api_base_url = 'https://graph.facebook.com/v18.0';
    private $timeout = 30;
    
    /**
     * Constructor
     *
     * @param string $api_token API token
     */
    public function __construct($api_token = '') {
        $this->api_token = $api_token ?: get_option('u43_whatsapp_api_token', '');
    }
    
    /**
     * Send message
     *
     * @param string $to Phone number
     * @param string $message Message text
     * @param array $options Additional options
     * @return array
     */
    public function send_message($to, $message, $options = []) {
        $phone_number_id = get_option('u43_whatsapp_phone_number_id', '');
        
        if (empty($phone_number_id)) {
            return [
                'success' => false,
                'message' => 'Phone number ID not configured. Please configure it in WhatsApp settings.'
            ];
        }
        
        $url = $this->api_base_url . '/' . $phone_number_id . '/messages';
        
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->format_phone_number($to),
            'type' => 'text',
            'text' => [
                'body' => $message
            ]
        ];
        
        return $this->make_request('POST', $url, $data);
    }
    
    /**
     * Send template message
     *
     * @param string $to Phone number
     * @param string $template_name Template name
     * @param array $template_params Template parameters
     * @param string $language_code Language code
     * @return array
     */
    public function send_template_message($to, $template_name, $template_params = [], $language_code = 'en_US') {
        $phone_number_id = get_option('u43_whatsapp_phone_number_id', '');
        
        if (empty($phone_number_id)) {
            return [
                'success' => false,
                'message' => 'Phone number ID not configured. Please configure it in WhatsApp settings.'
            ];
        }
        
        $url = $this->api_base_url . '/' . $phone_number_id . '/messages';
        
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->format_phone_number($to),
            'type' => 'template',
            'template' => [
                'name' => $template_name,
                'language' => [
                    'code' => $language_code
                ]
            ]
        ];
        
        // Add template parameters if provided
        if (!empty($template_params)) {
            $data['template']['components'] = [
                [
                    'type' => 'body',
                    'parameters' => array_map(function($param) {
                        return [
                            'type' => 'text',
                            'text' => $param
                        ];
                    }, $template_params)
                ]
            ];
        }
        
        return $this->make_request('POST', $url, $data);
    }
    
    /**
     * Send media
     *
     * @param string $to Phone number
     * @param string $media_url Media URL
     * @param string $media_type Media type (image, video, document, audio)
     * @param string $caption Caption (optional)
     * @return array
     */
    public function send_media($to, $media_url, $media_type, $caption = '') {
        $phone_number_id = get_option('u43_whatsapp_phone_number_id', '');
        
        if (empty($phone_number_id)) {
            return [
                'success' => false,
                'message' => 'Phone number ID not configured'
            ];
        }
        
        $url = $this->api_base_url . '/' . $phone_number_id . '/messages';
        
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->format_phone_number($to),
            'type' => $media_type,
            $media_type => [
                'link' => $media_url
            ]
        ];
        
        if (!empty($caption) && in_array($media_type, ['image', 'video', 'document'])) {
            $data[$media_type]['caption'] = $caption;
        }
        
        return $this->make_request('POST', $url, $data);
    }
    
    /**
     * Send template message
     *
     * @param string $to Phone number
     * @param string $template_name Template name
     * @param array $template_params Template parameters
     * @param string $language_code Language code
     * @return array
     */
    public function send_template($to, $template_name, $template_params = [], $language_code = 'en') {
        $phone_number_id = get_option('u43_whatsapp_phone_number_id', '');
        
        if (empty($phone_number_id)) {
            return [
                'success' => false,
                'message' => 'Phone number ID not configured'
            ];
        }
        
        $url = $this->api_base_url . '/' . $phone_number_id . '/messages';
        
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->format_phone_number($to),
            'type' => 'template',
            'template' => [
                'name' => $template_name,
                'language' => [
                    'code' => $language_code
                ]
            ]
        ];
        
        if (!empty($template_params)) {
            $data['template']['components'] = [
                [
                    'type' => 'body',
                    'parameters' => array_map(function($param) {
                        return [
                            'type' => 'text',
                            'text' => $param
                        ];
                    }, $template_params)
                ]
            ];
        }
        
        return $this->make_request('POST', $url, $data);
    }
    
    /**
     * Get phone number info
     *
     * @param string $phone_number Phone number
     * @return array
     */
    public function get_phone_number_info($phone_number) {
        $phone_number_id = get_option('u43_whatsapp_phone_number_id', '');
        
        if (empty($phone_number_id)) {
            return [
                'success' => false,
                'message' => 'Phone number ID not configured'
            ];
        }
        
        $url = $this->api_base_url . '/' . $phone_number_id;
        
        return $this->make_request('GET', $url);
    }
    
    /**
     * Make HTTP request
     *
     * @param string $method HTTP method
     * @param string $url URL
     * @param array $data Request data
     * @return array
     */
    public function make_request($method, $url, $data = []) {
        $args = [
            'method' => $method,
            'timeout' => $this->timeout,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_token,
                'Content-Type' => 'application/json'
            ]
        ];
        
        if ($method === 'POST' && !empty($data)) {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $decoded_body = json_decode($body, true);
        
        if ($status_code >= 200 && $status_code < 300) {
            return [
                'success' => true,
                'data' => $decoded_body
            ];
        }
        
        // Extract error message with more detail
        $error_message = 'Request failed';
        $error_code = $status_code;
        
        if (isset($decoded_body['error'])) {
            $error_message = $decoded_body['error']['message'] ?? 'Request failed';
            $error_code = $decoded_body['error']['code'] ?? $status_code;
            
            // Check for specific error types
            if (isset($decoded_body['error']['type'])) {
                $error_type = $decoded_body['error']['type'];
                
                // Handle authentication errors
                if (strpos($error_message, 'Session has expired') !== false || 
                    strpos($error_message, 'expired') !== false ||
                    $error_type === 'OAuthException') {
                    $error_message = 'WhatsApp API authentication failed. Your access token has expired. Please update your API token in WhatsApp settings. Original error: ' . $error_message;
                }
                
                // Handle rate limiting
                if ($error_type === 'OAuthException' && strpos($error_message, 'rate limit') !== false) {
                    $error_message = 'WhatsApp API rate limit exceeded. Please wait before sending more messages. Original error: ' . $error_message;
                }
            }
        }
        
        return [
            'success' => false,
            'message' => $error_message,
            'error_code' => $error_code,
            'raw_error' => $decoded_body['error'] ?? null
        ];
    }
    
    /**
     * Send marketing message (template message)
     * Marketing messages must use approved templates
     *
     * @param string $to Phone number
     * @param string $template_name Template name (must be approved)
     * @param array $template_params Template parameters
     * @param string $language_code Language code (default: en_US)
     * @return array
     */
    public function send_marketing_message($to, $template_name, $template_params = [], $language_code = 'en_US') {
        $phone_number_id = get_option('u43_whatsapp_phone_number_id', '');
        
        if (empty($phone_number_id)) {
            return [
                'success' => false,
                'message' => 'Phone number ID not configured. Please configure it in WhatsApp settings.'
            ];
        }
        
        $url = $this->api_base_url . '/' . $phone_number_id . '/messages';
        
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->format_phone_number($to),
            'type' => 'template',
            'template' => [
                'name' => $template_name,
                'language' => [
                    'code' => $language_code
                ]
            ]
        ];
        
        // Add template parameters if provided
        if (!empty($template_params)) {
            $components = [];
            
            // Body parameters
            if (isset($template_params['body']) && is_array($template_params['body'])) {
                $components[] = [
                    'type' => 'body',
                    'parameters' => array_map(function($param) {
                        return [
                            'type' => 'text',
                            'text' => $param
                        ];
                    }, $template_params['body'])
                ];
            }
            
            // Header parameters (for media or text headers)
            if (isset($template_params['header']) && is_array($template_params['header'])) {
                $header_params = [];
                foreach ($template_params['header'] as $param) {
                    if (isset($param['type']) && $param['type'] === 'image') {
                        $header_params[] = [
                            'type' => 'image',
                            'image' => [
                                'link' => $param['link']
                            ]
                        ];
                    } else {
                        $header_params[] = [
                            'type' => 'text',
                            'text' => is_array($param) ? $param['text'] : $param
                        ];
                    }
                }
                if (!empty($header_params)) {
                    $components[] = [
                        'type' => 'header',
                        'parameters' => $header_params
                    ];
                }
            }
            
            // Button parameters
            if (isset($template_params['buttons']) && is_array($template_params['buttons'])) {
                $button_params = [];
                foreach ($template_params['buttons'] as $index => $button) {
                    if (isset($button['type']) && $button['type'] === 'url') {
                        $button_params[] = [
                            'type' => 'button',
                            'sub_type' => 'url',
                            'index' => $index,
                            'parameters' => [
                                [
                                    'type' => 'text',
                                    'text' => $button['url']
                                ]
                            ]
                        ];
                    } elseif (isset($button['type']) && $button['type'] === 'quick_reply') {
                        $button_params[] = [
                            'type' => 'button',
                            'sub_type' => 'quick_reply',
                            'index' => $index,
                            'parameters' => [
                                [
                                    'type' => 'payload',
                                    'payload' => $button['payload']
                                ]
                            ]
                        ];
                    }
                }
                if (!empty($button_params)) {
                    $components = array_merge($components, $button_params);
                }
            }
            
            if (!empty($components)) {
                $data['template']['components'] = $components;
            }
        }
        
        return $this->make_request('POST', $url, $data);
    }
    
    /**
     * Format phone number
     *
     * @param string $phone_number Phone number
     * @return string Formatted phone number (without + prefix for WhatsApp Cloud API)
     */
    public function format_phone_number($phone_number) {
        // Remove all non-digit characters
        $phone_number = preg_replace('/[^\d]/', '', $phone_number);
        
        // WhatsApp Cloud API accepts phone numbers without + prefix
        // Just return the digits
        return $phone_number;
    }
}

