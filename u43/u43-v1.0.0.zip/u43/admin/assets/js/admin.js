/**
 * U43 Admin Scripts
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Admin scripts will go here
        console.log('U43 Admin loaded');
    });
})(jQuery);

